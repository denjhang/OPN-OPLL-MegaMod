                      Music Player Frontend for PT3 files

                       PT3 Player Code by Sergey Bulbas

                        Modified for ZX81 by Andy Rea

                           Frontend by Greg Harder

                                    2021
                      ===================================

Tested on a T/S 1000 with ZXpand+ (NTSC video) and a ZX81 (PAL video).

Recommended emulator is "sz81p", the ZXPand+ version. Note, the Ireg cycle op-
tion does not work with this emulator. The "EightyOne v1.21" emulator works,
but has problems with the music player's audio and display, it messes up EO's
display timing somewhere. However, the Ireg cycle option does work. The ZEsarUX
emulator doesn't like the program at all.

In short, the program works best on real hardware.

Features...

	Continuous play
	Back/Next keys
	Shuffle Mode
	Continuous loop option
	PT3 Info. display
	PAL tempo change
	Music video visualizations
	Wallpapers

This version is specific to the "ShockXXX.pt3" collection, which I downloaded
from somewhere.  It consists of 230 tunes.  You can add more tunes to the col-
lection if you want, just rename them "Shock231.pt3", "Shock232.pt3", etc. Put
the tunes into the "SHOCK" folder then edit line 9130 LET M$="230" with the 
numeric value of the last file. 

You can easily change the wallpapers if you want by editing a wallpaper drop-
down menu starting at line 1000, just replace any of the names, A to U, with 
your prefered wallpaper.  A wallpaper consists of a standard ZX81 screen dump,
792 bytes, with a .scr extension. Put the wallpaper in the "Walls" folder.

PAL vs NTSC

When playing tunes on a NTSC system you may notice that it plays at a faster
tempo than a PAL system.  This may seem strange and counterintuitive as a PAL
system actually runs faster than a NTSC system. The explanation, I think, has
to do with the interrupt driven music player. A PAL system spends more time
computing, (Margin)=55, than a NTSC system, (Margin)=31.  Therefore, the NTSC 
system gets back to playing music faster than the PAL system.  The "PAL SPEED"
option in the Files Menu fools a NTSC system into thinking it's a PAL system. 
It does this by changing the instruction at...

	40C6	LD A,(Margin) where (Margin)=31 on NTSC
to
	40C6	LD A,(Spare2) where (Spare2)=55 the PAL value

This will slow the tempo, but may distort the video display.  Actually, it pro-
duces a better display on my LCD monitor, with a sharper image and no distor-
tion, strange!  You may not have the same results though.  Older CRT monitors
and B&W TV's may be more sensitive to this adjustment as well. There's no 
point in using this option an a PAL system as there should be no speed change
at all.

On the otherhand you can fool a PAL system into thinking it's a NTCS system
by changing line...

	384 POKE 16507,55 the PAL margin value
to
	384 POKE 16507,31 the NTSC margin value

This will increase the tempo when the "PAL SPEED" option is selected. I don't
know what the display will look like though.  If you want to make this perma-
nent then edit lines 200 and 255 replacing PAL with NTC, then run 9990 to SAVE
with the changes.

Video Credits:

Ball Life based on "Life" by J. Ball, from Michael Orwin's Cassette 4, 1982.
Good Life based on "The ZX81 GAME of LIFE" by Wilf Rigter, 1983?
Kaleidoscope based on "Kaleidoscope" By S.H. McGurrin from Syntax v5,n01 p.19.
Survival based on "Survival" by frag/fsqrt, 2012.
Vertigo based on "Spiral Clear" by Gary Nugent from Your Comp. 11/1982 p.110
