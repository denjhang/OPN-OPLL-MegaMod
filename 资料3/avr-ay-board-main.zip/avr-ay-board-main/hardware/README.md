PCB v1.2|PCB v1.3|PCB v1.4
:-:|:-:|:-:
<img src="v1.2/AY-3-8912-Emulator-v1.2_PhotoTop.svg" width="480px">|<img src="v1.3/AY-3-8912-Emulator-v1.3_PhotoTop.svg" width="480px">|<img src="v1.4/AY-3-8912-Emulator-v1.4_PhotoTop.svg" width="480px">
<img src="v1.2/AY-3-8912-Emulator-v1.2_PhotoBottom.svg" width="480px">|<img src="v1.3/AY-3-8912-Emulator-v1.3_PhotoBottom.svg" width="480px">|<img src="v1.4/AY-3-8912-Emulator-v1.4_PhotoBottom.svg" width="480px">
Initial schematic and PCB design|New schematic and PCB design|Moved J1 closer to J2